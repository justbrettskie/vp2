import { serve } from 'https://deno.land/std@0.224.0/http/server.ts';
const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type', 'Access-Control-Allow-Methods': 'POST, OPTIONS' };
serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  try {
    const key = Deno.env.get('OPENAI_API_KEY');
    if (!key) return Response.json({ error: 'OPENAI_API_KEY is not configured in Supabase Edge Function secrets.' }, { status: 503, headers: cors });
    const { prompt, response_json_schema } = await req.json();
    const response = await fetch('https://api.openai.com/v1/chat/completions', { method: 'POST', headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ model: 'gpt-4o-mini', messages: [{ role: 'user', content: prompt ?? '' }], ...(response_json_schema ? { response_format: { type: 'json_schema', json_schema: { name: 'vitalpulse_response', strict: false, schema: response_json_schema } } } : {}) }) });
    const result = await response.json();
    if (!response.ok) return Response.json({ error: result.error?.message ?? 'AI provider request failed' }, { status: 502, headers: cors });
    const content = result.choices?.[0]?.message?.content ?? '{}';
    let parsed; try { parsed = JSON.parse(content); } catch { parsed = { text: content }; }
    return Response.json(parsed, { headers: cors });
  } catch (e) { return Response.json({ error: e.message ?? 'AI request failed' }, { status: 500, headers: cors }); }
});
