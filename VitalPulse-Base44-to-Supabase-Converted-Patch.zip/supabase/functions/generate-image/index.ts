import { serve } from 'https://deno.land/std@0.224.0/http/server.ts';
const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type', 'Access-Control-Allow-Methods': 'POST, OPTIONS' };
serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  try {
    const key = Deno.env.get('OPENAI_API_KEY');
    if (!key) return Response.json({ error: 'OPENAI_API_KEY is not configured in Supabase Edge Function secrets.' }, { status: 503, headers: cors });
    const { prompt } = await req.json();
    const response = await fetch('https://api.openai.com/v1/images/generations', { method: 'POST', headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ model: 'gpt-image-1', prompt: String(prompt ?? ''), size: '1024x1024' }) });
    const result = await response.json();
    if (!response.ok) return Response.json({ error: result.error?.message ?? 'Image generation failed' }, { status: 502, headers: cors });
    const item = result.data?.[0];
    if (item?.url) return Response.json({ url: item.url }, { headers: cors });
    if (item?.b64_json) return Response.json({ url: `data:image/png;base64,${item.b64_json}` }, { headers: cors });
    return Response.json({ error: 'Image provider returned no image.' }, { status: 502, headers: cors });
  } catch (e) { return Response.json({ error: e.message ?? 'Image generation failed' }, { status: 500, headers: cors }); }
});
