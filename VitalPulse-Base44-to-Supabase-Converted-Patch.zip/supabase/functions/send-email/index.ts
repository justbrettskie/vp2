import { serve } from 'https://deno.land/std@0.224.0/http/server.ts';
const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type', 'Access-Control-Allow-Methods': 'POST, OPTIONS' };
serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  try {
    const key = Deno.env.get('RESEND_API_KEY');
    const from = Deno.env.get('EMAIL_FROM');
    if (!key || !from) return Response.json({ error: 'Configure RESEND_API_KEY and EMAIL_FROM in Supabase Edge Function secrets.' }, { status: 503, headers: cors });
    const { to, subject, html, text } = await req.json();
    if (!to || !subject || (!html && !text)) return Response.json({ error: 'Expected to, subject, and html or text.' }, { status: 400, headers: cors });
    const response = await fetch('https://api.resend.com/emails', { method: 'POST', headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ from, to: Array.isArray(to) ? to : [to], subject, ...(html ? { html } : {}), ...(text ? { text } : {}) }) });
    const result = await response.json();
    if (!response.ok) return Response.json({ error: result.message ?? 'Email delivery failed' }, { status: 502, headers: cors });
    return Response.json(result, { headers: cors });
  } catch (e) { return Response.json({ error: e.message ?? 'Email request failed' }, { status: 500, headers: cors }); }
});
