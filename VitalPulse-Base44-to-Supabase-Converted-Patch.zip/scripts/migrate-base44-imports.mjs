// Run from the root of the complete VitalPulse React project:
// node scripts/migrate-base44-imports.mjs
// Rewrites Base44 client imports to the Supabase-backed compatibility adapter.
import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve('src');
function walk(dir) {
  for (const item of fs.readdirSync(dir, { withFileTypes: true })) {
    const file = path.join(dir, item.name);
    if (item.isDirectory()) walk(file);
    else if (/\.(jsx?|tsx?)$/.test(item.name) && !file.endsWith('base44Client.js')) {
      let text = fs.readFileSync(file, 'utf8');
      text = text.replace(/import\s*\{\s*base44\s*\}\s*from\s*(['"])@\/api\/base44Client\1/g, "import { supabaseApi } from '@/api/supabaseApi'");
      text = text.replace(/\bbase44\./g, 'supabaseApi.');
      fs.writeFileSync(file, text);
    }
  }
}
walk(root);
console.log('Rewrote Base44 client imports where found. Review all remaining Base44 references before building.');
