import { supabase } from '@/lib/supabase';

const TABLES = { HealthProfile: 'health_profiles', ActivitySession: 'activity_sessions', Payment: 'payments' };
const mapRow = (row) => row ? ({ ...row, created_date: row.created_at ?? row.created_date, created_by_id: row.user_id ?? row.created_by_id }) : row;
const mapRows = (rows) => (rows ?? []).map(mapRow);
async function currentUser() {
  const { data, error } = await supabase.auth.getUser();
  if (error) throw error;
  if (!data.user) throw new Error('Please sign in first.');
  return data.user;
}
function dbPayload(entity, input = {}, userId) {
  const out = { ...input };
  delete out.id; delete out.created_date; delete out.created_by_id; delete out.created_by;
  if (entity === 'HealthProfile') {
    if ('created_date' in input) delete out.created_date;
    out.user_id = userId;
    out.updated_at = new Date().toISOString();
  } else if (entity === 'ActivitySession') {
    out.user_id = userId;
  }
  return out;
}
function sortSpec(sort) {
  const desc = typeof sort === 'string' && sort.startsWith('-');
  const field = typeof sort === 'string' ? sort.replace(/^-/, '') : 'created_at';
  const column = field === 'created_date' ? 'created_at' : field;
  return { column, ascending: !desc };
}
async function listEntity(entity, sort = '-created_date', limit) {
  const table = TABLES[entity];
  if (!table) throw new Error(`Unsupported entity: ${entity}`);
  const { column, ascending } = sortSpec(sort);
  let q = supabase.from(table).select('*').order(column, { ascending });
  if (Number.isFinite(limit)) q = q.limit(limit);
  const { data, error } = await q;
  if (error) throw error;
  return mapRows(data);
}
async function createEntity(entity, input = {}) {
  if (entity === 'Payment') {
    throw new Error('Payments cannot be marked completed by the app. Start Stripe Checkout and let a verified Stripe webhook update payment status.');
  }
  const user = await currentUser();
  const { data, error } = await supabase.from(TABLES[entity]).insert(dbPayload(entity, input, user.id)).select().single();
  if (error) throw error;
  return mapRow(data);
}
async function updateEntity(entity, id, input = {}) {
  if (entity === 'Payment') throw new Error('Payment records can only be updated by a trusted server-side Stripe webhook.');
  const user = await currentUser();
  const { data, error } = await supabase.from(TABLES[entity]).update(dbPayload(entity, input, user.id)).eq('id', id).select().single();
  if (error) throw error;
  return mapRow(data);
}
async function filterEntity(entity, filters = {}) {
  const table = TABLES[entity];
  if (!table) throw new Error(`Unsupported entity: ${entity}`);
  let q = supabase.from(table).select('*');
  const user = await currentUser();
  q = q.eq('user_id', user.id);
  for (const [key, value] of Object.entries(filters)) {
    const col = key === 'created_by_id' ? 'user_id' : key;
    q = value === null ? q.is(col, null) : q.eq(col, value);
  }
  const { data, error } = await q;
  if (error) throw error;
  return mapRows(data);
}
async function aggregateActivity({ groupBy = 'session_date', sum = [], avg = [], limit = 90 } = {}) {
  // PostgREST doesn't provide arbitrary aggregate/group-by queries directly.
  // Fetch the caller's own rows, then calculate the same simple aggregates client-side.
  const rows = await listEntity('ActivitySession', `-${groupBy}`, limit * 50);
  const groups = new Map();
  for (const row of rows) {
    const key = row[groupBy] ?? 'unknown';
    if (!groups.has(key)) groups.set(key, { [groupBy]: key, _count: 0 });
    const g = groups.get(key); g._count += 1;
    for (const f of sum) g[f] = (g[f] ?? 0) + (Number(row[f]) || 0);
    for (const f of avg) { g[`avg_${f}`] = (g[`avg_${f}`] ?? 0) + (Number(row[f]) || 0); g[`__count_${f}`] = (g[`__count_${f}`] ?? 0) + (row[f] == null ? 0 : 1); }
  }
  const out = [...groups.values()].sort((a,b) => String(b[groupBy]).localeCompare(String(a[groupBy]))).slice(0, limit);
  for (const g of out) for (const f of avg) { g[`avg_${f}`] = g[`__count_${f}`] ? g[`avg_${f}`] / g[`__count_${f}`] : null; delete g[`__count_${f}`]; }
  return { rows: out };
}

export const supabaseApi = {
  entities: {
    HealthProfile: {
      list: (sort, limit) => listEntity('HealthProfile', sort, limit),
      create: (data) => createEntity('HealthProfile', data),
      update: (id, data) => updateEntity('HealthProfile', id, data),
    },
    ActivitySession: {
      list: (sort, limit) => listEntity('ActivitySession', sort, limit),
      create: (data) => createEntity('ActivitySession', data),
      aggregate: aggregateActivity,
    },
    Payment: {
      filter: (filters) => filterEntity('Payment', filters),
      create: (data) => createEntity('Payment', data),
    },
  },
  auth: {
    me: async () => {
      const user = await currentUser();
      return { id: user.id, email: user.email, ...user.user_metadata, role: user.role };
    },
    isAuthenticated: async () => !!(await supabase.auth.getUser()).data.user,
    logout: async (redirectUrl) => {
      const { error } = await supabase.auth.signOut(); if (error) throw error;
      if (typeof redirectUrl === 'string' && redirectUrl) window.location.assign('/Login');
    },
    redirectToLogin: () => window.location.assign('/Login'),
    loginViaEmailPassword: async (email, password) => {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error; return data;
    },
    register: async ({ email, password, ...metadata }) => {
      const { data, error } = await supabase.auth.signUp({ email, password, options: { data: metadata, emailRedirectTo: `${window.location.origin}/Login` } });
      if (error) throw error; return data;
    },
    verifyOtp: async ({ email, otpCode }) => {
      const { data, error } = await supabase.auth.verifyOtp({ email, token: otpCode, type: 'signup' });
      if (error) throw error; return data;
    },
    resendOtp: async (email) => {
      const { data, error } = await supabase.auth.resend({ type: 'signup', email });
      if (error) throw error; return data;
    },
    resetPasswordRequest: async (email) => {
      const { data, error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: `${window.location.origin}/ResetPassword` });
      if (error) throw error; return data;
    },
    resetPassword: async ({ newPassword }) => {
      const { data, error } = await supabase.auth.updateUser({ password: newPassword });
      if (error) throw error; return data;
    },
    loginWithProvider: async (provider, returnTo) => {
      const { data, error } = await supabase.auth.signInWithOAuth({ provider, options: { redirectTo: typeof returnTo === 'string' ? returnTo : `${window.location.origin}/` } });
      if (error) throw error; return data;
    },
    // Base44 access tokens cannot be safely transferred to Supabase. Use Supabase sign-in instead.
    setToken: async () => { throw new Error('Base44 tokens are not compatible with Supabase. Sign in again using Supabase Auth.'); },
  },
  integrations: { Core: {
    InvokeLLM: async (body) => { const { data, error } = await supabase.functions.invoke('ai-insights', { body }); if (error) throw error; return data; },
    GenerateImage: async (body) => { const { data, error } = await supabase.functions.invoke('generate-image', { body }); if (error) throw error; return data; },
    SendEmail: async (body) => { const { data, error } = await supabase.functions.invoke('send-email', { body }); if (error) throw error; return data; },
  } },
};
