# VitalPulse Base44 → Supabase migration patch

This patch replaces the Base44 SDK dependency with Supabase-backed client operations for the source files supplied in the text export. It is **not a complete app repository or a rebuilt APK**: the supplied export omits `package.json`, Vite configuration, several of the 44 files, and Android build/signing files.

## Contents
- `src/lib/supabase.js`: Supabase client using the publishable key only.
- `src/api/supabaseApi.js`: Supabase-backed migration adapter for HealthProfile, ActivitySession, Payment reads, auth, and Edge Function integrations.
- `src/lib/AuthContext.jsx`: removes Base44 public-settings API and uses Supabase Auth session state.
- `supabase/functions/*`: secure server-side examples for AI, image generation, and email.
- `scripts/migrate-base44-imports.mjs`: optional script to update imports/references in a complete source tree.
- `src/api/base44Client.js`: temporary re-export for any components not yet migrated. It does not import the Base44 SDK.

## Apply to your complete source project
1. Back up the full VitalPulse source folder first.
2. Copy the `src` and `supabase` folders from this patch into the matching locations in the complete source project. Review conflicts rather than blindly overwriting your files.
3. Install the dependency in the project: `npm install @supabase/supabase-js`.
4. Add `.env.local` using `.env.example`; paste your Supabase **Project URL** and **publishable key**. Do not use a service-role key in the app.
5. Run the SQL migration in the Supabase SQL Editor only after reviewing whether the tables/policies already exist.
6. Deploy the Edge Functions and set secrets: `OPENAI_API_KEY`, `RESEND_API_KEY`, and `EMAIL_FROM` as needed. Keep provider keys in Edge Function secrets, never in browser/APK code.
7. Either keep the temporary compatibility import (`base44Client.js`) while testing or run `node scripts/migrate-base44-imports.mjs` from the complete project root. Review all changed files and remaining `base44` text.
8. Configure Supabase Auth providers and redirect URLs, then test sign-up, OTP, OAuth, password reset, health profile save/load, and activity history.
9. Do not treat a client-created payment as paid. The adapter blocks simulated completed payments; Stripe checkout creation and a verified Stripe webhook still need to be configured before paid access can work.
10. Build and test the web bundle and Android wrapper with the original project toolchain. Do not install this patch as an APK.

## Important behavior differences
- `HealthProfile` and `ActivitySession` map to `health_profiles` and `activity_sessions` and require a signed-in Supabase user.
- Activity aggregate requests are calculated from the current user's fetched rows; for large datasets, replace this with a Postgres RPC for efficient server-side aggregation.
- Payment creation is deliberately blocked on the client for security. A trusted Stripe webhook/Edge Function must mark payments completed.
- Base44-issued tokens cannot be transferred to Supabase; users must sign in again through Supabase Auth.
- This adapter is a migration bridge. Review its mappings against every component's expected field names before production use.
