# VitalPulse — fresh Android + Supabase setup

This is a fresh packaging of the existing VitalPulse Android WebView wrapper, the supplied compiled frontend assets, the supplied source-code text reference, and the Supabase migration/function starter. It uses the latest Supabase project details provided in chat.

## Supabase project configuration

- Project URL: `https://pnxyowqmwnsnwodlexug.supabase.co`
- Client key: the current publishable key is stored in `.env.local` for the editable Vite/React source workflow.
- `.env.local` is git-ignored. `.env.example` is a template.

A Supabase publishable key is intended for client use, but it does not authorize access by itself. Enable and verify Row Level Security (RLS) for every table containing user data. Never place a `service_role` key, secret API key, database password, or signing password in this project.

## What is included

- Android Studio Gradle wrapper project and WebView activity
- Compiled VitalPulse frontend assets from the provided migration starter
- Supabase SQL migration under `supabase/migrations/`
- AI coach and checkout Edge Function starter files
- Supabase JS client helper under `src/lib/supabase.ts`
- Existing extracted source reference under `source-reference/`
- `.env.local` with the current project URL and latest publishable key supplied in chat

## Important integration status

This is a starter project, not a verified production migration. The compiled frontend assets currently shipped in `app/src/main/assets/` were built before the new Supabase helper was added. The helper in `src/lib/supabase.ts` is not automatically used by the compiled bundle. Base44 calls in the editable source must be migrated feature by feature and the frontend rebuilt before Supabase-backed login, profiles, activity history, AI coaching, or subscriptions can be considered connected.

The checkout function is a placeholder and is not a production payment flow. Do not represent a simulated payment as a verified payment. Review the SQL and RLS policies before applying the migration to your live project; back up any existing data first.

## Build the Android App Bundle

1. Install Android Studio and its Android SDK (API 35 or a compatible installed platform).
2. Open this folder (`VitalPulse_AndroidStudio_Project`) in Android Studio.
3. Let Gradle sync and install any missing SDK components.
4. Run the app on a device/emulator and verify the frontend first.
5. Choose **Build → Generate Signed Bundle / APK → Android App Bundle**.
6. Create/select your release signing key locally. Never upload the signing key or password into chat.

This environment has no Android SDK/Gradle installation, so it cannot compile or sign the `.aab` here. The current bundle is a project ZIP, not an `.aab` file.
