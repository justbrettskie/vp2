// Secure checkout placeholder. Configure Stripe secret, server-selected Price IDs,
// success/cancel URLs, and a signature-verified webhook before enabling payments.
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type', 'Access-Control-Allow-Methods': 'POST, OPTIONS' };
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return new Response('Method not allowed', { status: 405, headers: cors });
  const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, { global: { headers: { Authorization: req.headers.get('Authorization') ?? '' } } });
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error || !user) return Response.json({ error: 'Sign in required' }, { status: 401, headers: cors });
  // Deliberately fail closed: no checkout is created until Stripe server secrets and webhook exist.
  return Response.json({ error: 'Stripe checkout is not configured yet', next_step: 'Set server-side Stripe secrets and implement a verified webhook.' }, { status: 503, headers: cors });
});
