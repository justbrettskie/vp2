import { useEffect, useState, type ReactNode } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { supabase } from '../lib/supabase';

export function AuthGate({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  const [signedIn, setSignedIn] = useState(false);
  const location = useLocation();
  useEffect(() => {
    let alive = true;
    supabase.auth.getUser().then(({ data }) => {
      if (alive) { setSignedIn(Boolean(data.user)); setReady(true); }
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      if (alive) { setSignedIn(Boolean(session?.user)); setReady(true); }
    });
    return () => { alive = false; listener.subscription.unsubscribe(); };
  }, []);
  if (!ready) return <div role="status">Checking your session…</div>;
  if (!signedIn) return <Navigate to="/login" replace state={{ from: location }} />;
  return <>{children}</>;
}
