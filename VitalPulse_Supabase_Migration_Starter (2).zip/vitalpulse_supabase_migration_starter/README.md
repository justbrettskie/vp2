# Vital Pulse — Supabase migration starter

This is a **starter package**, not a completed APK-to-AAB conversion. It includes the supplied Supabase data helper and SQL migration, a React Router auth gate, a server-side AI coach function, and a fail-closed Stripe checkout placeholder.

## Critical limitation
The uploaded APK is a compiled Android package with a bundled/minified web UI. It does not contain the original editable project, complete source maps, Gradle project, or signing configuration needed to safely modify the app and build a release Android App Bundle. The extracted frontend under `android-notes/` is reference-only and has not been wired to the new modules. This environment has no Android SDK, Gradle, or bundletool, so it cannot produce/sign a release `.aab` from the APK alone.

To finish this and generate an actual `.aab`, provide the original source project ZIP or repository, including `package.json`, Base44 integration/source, and Android/Capacitor or native project files. Do not send signing passwords or private signing keys.

## Supabase client (React/Vite)
1. Install `@supabase/supabase-js` and `react-router-dom` in the original project.
2. Copy `src/lib/supabase.ts`, `src/lib/vitalPulseData.js`, and `src/auth/AuthGate.tsx` into it.
3. Set these local environment variables (do not commit `.env.local`):
   ```
   VITE_SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
   VITE_SUPABASE_PUBLISHABLE_KEY=YOUR_PUBLISHABLE_KEY
   ```
4. Wrap private routes with `AuthGate`. Route guards alone do not secure data; use RLS policies too.
5. Review the SQL before applying it. The supplied migration creates policies without `IF NOT EXISTS`, so repeated execution may fail.

## AI coach
The Edge Function requires a signed-in user and keeps `OPENAI_API_KEY` on the server. Set it as a Supabase Function secret and deploy `ai-coach`. The prompt is tailored to general fitness/wellness, not diagnosis or treatment. Review privacy and health-data handling before production.

## Stripe
The supplied `pk_live_...` value is a publishable key, not a secret key. Do not treat it as authentication or proof of payment. A secure subscription flow needs a server-side Stripe secret stored in Supabase secrets, server-selected Price IDs, and a Stripe webhook with signature verification that updates subscription state. The checkout function intentionally fails closed until that is implemented.

## Android bundle
After the changes are integrated into the actual source project, build a release App Bundle using the project's supported Android tooling (typically Android Studio / Gradle `bundleRelease`). The `.aab` must be built and signed from the source project; it cannot be reliably reconstructed from the APK alone.
